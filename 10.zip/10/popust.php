<?php



function izracunajPopust($cena, $procenatPopusta)
{
    $procenatPopusta = $procenatPopusta/100;
    return $cena*$procenatPopusta;
}

$popust = izracunajPopust(345, 16);
echo $popust;








?>