<?php


// proba verzija 
// full domaci      dostava_rastojanje2.php

    function izracunajCenuSaDostavom($cena, $rastojanje)
    {
    
        $dostava = 0;
        if($rastojanje < 100)
        {
            $dostava = 200;
        }
        else if ($rastojanje >= 100 && $rastojanje < 200)
        {
            $dostava = 350;
        }
        else if($rastojanje >= 200 && $rastojanje < 300)
        {
            $dostava = 450;
        }
        else 
        {
            $dostava = 1000;
        }
        return $cena+$dostava;
    }
    
    
    $gradovi = [
    
    
        "Obrenovac" => 32,
        "Novi sad" => 76,
        "Požarevac" => 85,
        "Subotica" => 175,
        "Niš" => 235,
        "Sarajevo" => 260,
        "Mitrovica" => 397,
        "Beč" => 546,
        "Atina" => 1040
    
    ];
    
    
    foreach($gradovi as $grad)
    {
    $cenaSaDostavom = izracunajCenuSaDostavom(100, $grad);
    
    echo $cenaSaDostavom;
    }













?>