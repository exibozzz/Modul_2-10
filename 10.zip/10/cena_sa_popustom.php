<?php



// Funkcija izračunavanje cene sa popustom  

function izracunajCenuSaPopustom($cena,$procenatPopusta)
{
    $procenatPopusta = $procenatPopusta/100;
    $popust = $cena*$procenatPopusta;
    return $cena-$popust;
}

$cenaSaPopustom = izracunajCenuSaPopustom(345, 16);

echo $cenaSaPopustom;














?>