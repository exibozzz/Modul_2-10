<?php

$trenutnaGodina = date("Y");
echo $trenutnaGodina;



// Izracunaj kamatu na osnovu godine


    function izracunajKamatu($kredit, $godina)
    {
        $kamatnaStopa = 0;

        if($godina < 2000) 
        {
            $kamatnaStopa = 0.05;
        }

    else if($godina >= 2000 && $godina < 2010)
        {
             $kamatnaStopa = 0.08;
        }

    else if($godina >= 2010 && $godina < 2020 )
        {
             $kamatnaStopa = 0.1;
        }

    else 
        {
             $kamatnaStopa = 0.14;
        }

    return $kredit*$kamatnaStopa;
    }




    $kamata = izracunajKamatu(628, 2021);

    echo $kamata;






?>