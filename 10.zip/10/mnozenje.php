<?php


// Funkcija za mnozenje brojeva sa returnom 
    
    function pomnoziBrojeve($prviBroj, $drugiBroj)
    {
        return $prviBroj*$drugiBroj;
    }
    
    
    $mnozenje = pomnoziBrojeve(55, 10);
    echo $mnozenje;
    






?>