<?php





    function izracunajCenuSaDostavom($cena, $grad)
    {
        $cenaDostave = 0;
        $gradovi = [
        
            "Obrenovac" => 32,
            "Novi sad" => 76,
            "Požarevac" => 85,
            "Subotica" => 175,
            "Niš" => 235,
            "Sarajevo" => 260,
            "Mitrovica" => 397,
            "Beč" => 546,
            "Atina" => 1040
        ];
    
    
        $proveraGrada = array_key_exists($grad, $gradovi);
        if($proveraGrada == true)
        {
            $rastojanje = $gradovi[$grad];
        
            // Pocetak if-a unutar if-a
            if($rastojanje < 100)
            {
                $cenaDostave = 200;
            }
            else if($rastojanje >= 100 && $rastojanje < 200)
            {
                $cenaDostave = 350;
            }
            else if($rastojanje >= 200 && $rastojanje <300)
            {
                $cenaDostave = 500;
            }
            else 
            {
                $cenaDostave = 1000;
            }
            // Kraj if-a unutar if-a
        
            $cenaSaDostavom = $cena+$cenaDostave;
        
        
            echo "Cena sa dostavom iznosi $cenaSaDostavom ";
            
        }
        else 
        {
            echo "Grad nema mogućnost poručivanja.";
        }
    
    }
    
    izracunajCenuSaDostavom(1500, "Atina");
    izracunajCenuSaDostavom(1500, "Obrenovac");
    izracunajCenuSaDostavom(1500, "Subotica");
    izracunajCenuSaDostavom(1500, "Mitrovica");
    














?>